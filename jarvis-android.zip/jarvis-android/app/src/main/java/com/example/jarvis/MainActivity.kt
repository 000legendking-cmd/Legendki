package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Setup screen: grant permissions, switch Jarvis on, and test commands by typing. */
class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
            setBackgroundColor(Color.parseColor("#050B14"))
        }
        col.addView(label("JARVIS", 34f, true, Color.parseColor("#4FD8FF")))
        status = label("", 14f, false, Color.parseColor("#9FC3D6"))
        col.addView(status)

        col.addView(label("1. Setup", 18f, true))
        col.addView(button("Grant permissions") {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
                Manifest.permission.ANSWER_PHONE_CALLS
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })
        col.addView(button("Turn on Jarvis accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("Stop Android putting Jarvis to sleep") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.addView(label("2. AI brain (optional)", 18f, true))
        val key = EditText(this).apply {
            hint = "Anthropic API key"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        col.addView(key)
        col.addView(button("Save key") {
            prefs.edit().putString("api_key", key.text.toString().trim()).apply()
            status.text = "API key saved."
        })

        col.addView(label("3. Run", 18f, true))
        col.addView(button("Start hands-free listening") {
            val i = Intent(this, JarvisService::class.java)
            startForegroundService(i)
            refresh()
        })
        col.addView(button("Stop listening") {
            stopService(Intent(this, JarvisService::class.java))
            refresh()
        })

        col.addView(label("Try a command by typing", 14f, false, Color.parseColor("#9FC3D6")))
        val test = EditText(this).apply {
            hint = "e.g. open settings"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            gravity = Gravity.START
        }
        col.addView(test)
        col.addView(button("Run command") {
            val svc = JarvisService.instance
            if (svc == null) status.text = "Start listening first."
            else svc.runCommand(test.text.toString())
        })

        col.addView(label(
            "Say \"Jarvis\" then a command, for example: \"Jarvis, open YouTube\", " +
                "\"Jarvis, scroll down\", \"Jarvis, tap Search\", \"Jarvis, call Mom\".",
            13f, false, Color.parseColor("#6F93A8")
        ))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#050B14"))
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0
        val a11y = JarvisAccessibilityService.instance != null
        val on = JarvisService.instance != null
        status.text = "Microphone: ${yn(mic)}\nAccessibility service: ${yn(a11y)}\nListening: ${yn(on)}"
    }

    private fun yn(b: Boolean) = if (b) "on" else "off"
}
