package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Performs taps, swipes, typing and system navigation on the user's voice command. */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---- system actions ----
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun lockScreen() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun screenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    // ---- gestures ----
    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return dispatch(p, 60)
    }

    /** direction is the way the content should move through the screen: "down" scrolls the page down. */
    fun swipe(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "down" -> { p.moveTo(w / 2, h * 0.70f); p.lineTo(w / 2, h * 0.30f) }
            "up" -> { p.moveTo(w / 2, h * 0.30f); p.lineTo(w / 2, h * 0.70f) }
            "left" -> { p.moveTo(w * 0.80f, h / 2); p.lineTo(w * 0.20f, h / 2) }
            else -> { p.moveTo(w * 0.20f, h / 2); p.lineTo(w * 0.80f, h / 2) }
        }
        return dispatch(p, 300)
    }

    // ---- reading the screen ----
    private fun findBest(root: AccessibilityNodeInfo, query: String): AccessibilityNodeInfo? {
        var exact: AccessibilityNodeInfo? = null
        var partial: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val label = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: ""))
                .trim().lowercase()
            if (label.isNotEmpty()) {
                if (label == query) {
                    if (exact == null) exact = n
                } else if (label.contains(query)) {
                    if (partial == null) partial = n
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return exact ?: partial
    }

    /** Taps the on-screen element whose text or description matches the query. */
    fun tapText(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findBest(root, query.lowercase().trim()) ?: return false
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return tapAt(r.centerX().toFloat(), r.centerY().toFloat())
    }

    // ---- typing ----
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val existing = if (field.isShowingHintText) "" else (field.text?.toString() ?: "")
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            existing + text
        )
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val field = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }
}
