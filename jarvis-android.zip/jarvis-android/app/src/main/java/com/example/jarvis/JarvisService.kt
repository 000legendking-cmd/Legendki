package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Always-on listener: waits for "Jarvis", then runs the command that follows. */
class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL = "jarvis_listening"
        @Volatile
        var instance: JarvisService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var active = false
    private var speaking = false
    private var awaitingCommand = false
    private lateinit var router: CommandRouter

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" followed by a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(tap)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
        router = CommandRouter(this) { say(it) }
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale.getDefault()
        tts.setPitch(0.9f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = resumeListening()
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = resumeListening()
        })
        ttsReady = true
        say("Jarvis online.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        active = true
        main.post { listen() }
        return START_STICKY
    }

    override fun onDestroy() {
        active = false
        instance = null
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        if (ttsReady) tts.shutdown()
        super.onDestroy()
    }

    // ---- speaking ----
    fun say(text: String) {
        main.post {
            if (!ttsReady) return@post
            speaking = true
            recognizer?.cancel()
            tts.speak(text, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
        }
    }

    private fun resumeListening() {
        main.post {
            if (!tts.isSpeaking) {
                speaking = false
                main.postDelayed({ listen() }, 250)
            }
        }
    }

    /** Lets the app screen run a typed command through the same router. */
    fun runCommand(text: String) {
        main.post { router.handle(text) }
    }

    // ---- listening ----
    private fun listen() {
        if (!active || speaking) return
        if (SpeechRecognizer.isRecognitionAvailable(this).not()) {
            say("Speech recognition isn't available on this phone.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(listener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            main.postDelayed({ listen() }, 1500)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!heard.isNullOrBlank()) handleHeard(heard)
            if (!speaking) main.postDelayed({ listen() }, 250)
        }

        override fun onError(error: Int) {
            if (speaking) return
            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 300L
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) recognizer?.cancel()
            main.postDelayed({ listen() }, delay)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private val wakeWord = Regex("jarvis|jervis|jarvas|service")

    private fun handleHeard(heard: String) {
        val t = heard.lowercase().trim()
        if (router.hasPending()) {
            router.handle(t)
            return
        }
        if (awaitingCommand) {
            awaitingCommand = false
            router.handle(t)
            return
        }
        val m = wakeWord.find(t) ?: return
        val cmd = t.substring(m.range.last + 1).trim(' ', ',', '.')
        if (cmd.isEmpty()) {
            awaitingCommand = true
            say("Yes?")
        } else {
            router.handle(cmd)
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis listening", NotificationManager.IMPORTANCE_LOW)
        )
    }
}
