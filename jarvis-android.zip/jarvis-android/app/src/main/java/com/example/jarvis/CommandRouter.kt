package com.example.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Turns a spoken or typed command into an action on the phone. */
class CommandRouter(private val ctx: Context, private val say: (String) -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private var pending: (() -> Unit)? = null
    private val history = JSONArray()

    fun hasPending() = pending != null

    private val a11y get() = JarvisAccessibilityService.instance

    private fun has(c: String, vararg words: String) = words.any { c.contains(it) }

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            say("I couldn't open that.")
        }
    }

    /** Runs an action that needs the accessibility service, with a helpful message if it is off. */
    private fun control(doneMessage: String, block: (JarvisAccessibilityService) -> Boolean) {
        val s = a11y
        if (s == null) {
            say("Please turn on the Jarvis accessibility service in settings.")
            return
        }
        if (block(s)) say(doneMessage) else say("I couldn't do that.")
    }

    fun handle(raw: String) {
        val cmd = raw.lowercase().trim().trim('.', ',', '!', '?')

        pending?.let { action ->
            pending = null
            if (has(cmd, "yes", "yeah", "yep", "sure", "confirm", "go ahead", "do it")) action()
            else say("Cancelled.")
            return
        }
        if (cmd.isEmpty()) return

        val tapMatch = Regex("^(tap|click|press|select)( on)? (.+)").find(cmd)

        when {
            has(cmd, "stop listening", "shut down jarvis", "goodbye jarvis") -> {
                say("Powering down. Goodbye.")
                main.postDelayed({ ctx.stopService(Intent(ctx, JarvisService::class.java)) }, 2500)
            }

            // ---- navigation and screen control (accessibility) ----
            has(cmd, "go home", "home screen") -> control("Home.") { it.home() }
            cmd == "go back" || cmd == "back" -> control("Back.") { it.back() }
            has(cmd, "recent apps", "app switcher", "recents") -> control("Recent apps.") { it.recents() }
            has(cmd, "lock the phone", "lock my phone", "lock screen") -> control("Locking.") { it.lockScreen() }
            has(cmd, "screenshot", "screen shot") -> control("Screenshot taken.") { it.screenshot() }
            has(cmd, "open notifications", "show notifications", "pull down notifications") ->
                control("Here are your notifications.") { it.notifications() }
            has(cmd, "quick settings") -> control("Quick settings.") { it.quickSettings() }
            has(cmd, "scroll down", "swipe up") -> control("Done.") { it.swipe("down") }
            has(cmd, "scroll up", "swipe down") -> control("Done.") { it.swipe("up") }
            has(cmd, "swipe left") -> control("Done.") { it.swipe("left") }
            has(cmd, "swipe right") -> control("Done.") { it.swipe("right") }
            tapMatch != null -> {
                val target = tapMatch.groupValues[3].trim()
                if (target == "enter" || target == "the enter key") control("Enter.") { it.pressEnter() }
                else control("Tapped $target.") { it.tapText(target) }
            }
            cmd.startsWith("type ") -> control("Typed.") { it.typeText(cmd.removePrefix("type ")) }

            // ---- calls and messages ----
            has(cmd, "answer the call", "pick up the call", "accept the call") -> answerCall()
            has(cmd, "end the call", "hang up", "reject the call") -> endCall()
            Regex("^(call|phone|ring) .+").matches(cmd) -> callContact(cmd.replace(Regex("^(call|phone|ring) "), ""))
            Regex("^(text|message|sms) .+ (saying|that says|say) .+").matches(cmd) -> textContact(cmd)

            // ---- media ----
            cmd in setOf("pause", "resume", "pause music", "resume music", "pause the music",
                "stop the music", "play music", "play") -> media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            has(cmd, "next song", "next track", "skip song") -> media(KeyEvent.KEYCODE_MEDIA_NEXT)
            has(cmd, "previous song", "previous track", "last song") -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS)

            // ---- device ----
            has(cmd, "flashlight", "torch") -> torch(!has(cmd, "off"))
            has(cmd, "volume", "louder", "quieter", "mute") -> volume(cmd)
            has(cmd, "wifi", "wi-fi", "wi fi") -> {
                launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                say("Here are your connection settings. Android doesn't let apps flip Wi-Fi directly.")
            }
            has(cmd, "battery") -> battery()
            has(cmd, "what time", "the time") -> say("It's " + fmt("h:mm a"))
            has(cmd, "what's the date", "what is the date", "today's date", "what day") ->
                say("Today is " + fmt("EEEE, MMMM d"))
            has(cmd, "timer") -> timer(cmd)
            has(cmd, "alarm") -> alarm(cmd)

            // ---- apps and web ----
            cmd.startsWith("navigate to") || cmd.startsWith("directions to") || cmd.startsWith("take me to") -> {
                val place = cmd.replace(Regex("^(navigate to|directions to|take me to) "), "")
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))))
                say("Navigating to $place.")
            }
            cmd.startsWith("search") || cmd.startsWith("google ") -> {
                val q = cmd.replace(Regex("^(search for|search|google) "), "")
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                say("Searching for $q.")
            }
            cmd.startsWith("play ") -> {
                val q = cmd.removePrefix("play ").removeSuffix(" on youtube")
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                say("Playing $q.")
            }
            cmd.startsWith("open ") -> openApp(cmd.removePrefix("open ").trim())

            has(cmd, "reset", "new conversation") -> {
                while (history.length() > 0) history.remove(0)
                say("Conversation cleared.")
            }
            has(cmd, "help", "what can you do") -> say(
                "I can navigate your phone, tap and type on screen, call and text contacts, " +
                    "open apps, set timers and alarms, control media and volume, and answer questions."
            )
            else -> askAi(cmd)
        }
    }

    private fun fmt(pattern: String) = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())

    // ---- calls ----
    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun findNumber(name: String): Pair<String, String>? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val col = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(col, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "$col LIKE ?", arrayOf("%$name%"), null
        )?.use { c ->
            if (c.moveToFirst()) return Pair(c.getString(0), c.getString(1))
        }
        return null
    }

    private fun callContact(name: String) {
        if (!granted(Manifest.permission.CALL_PHONE)) { say("I need the phone permission first."); return }
        val hit = findNumber(name)
        if (hit == null) { say("I couldn't find $name in your contacts."); return }
        say("Shall I call ${hit.first}?")
        pending = {
            launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(hit.second))))
            say("Calling ${hit.first}.")
        }
    }

    private fun textContact(cmd: String) {
        val m = Regex("^(?:text|message|sms) (.+?) (?:saying|that says|say) (.+)").find(cmd) ?: return
        if (!granted(Manifest.permission.SEND_SMS)) { say("I need the SMS permission first."); return }
        val hit = findNumber(m.groupValues[1])
        if (hit == null) { say("I couldn't find ${m.groupValues[1]} in your contacts."); return }
        val body = m.groupValues[2]
        say("Shall I text ${hit.first}: $body?")
        pending = {
            try {
                val sms = ctx.getSystemService(SmsManager::class.java)
                sms.sendMultipartTextMessage(hit.second, null, sms.divideMessage(body), null, null)
                say("Message sent.")
            } catch (e: Exception) {
                say("I couldn't send that message.")
            }
        }
    }

    private fun answerCall() {
        if (!granted(Manifest.permission.ANSWER_PHONE_CALLS)) { say("I need call permission first."); return }
        try {
            ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
            say("Answering.")
        } catch (e: Exception) { say("I couldn't answer.") }
    }

    private fun endCall() {
        if (!granted(Manifest.permission.ANSWER_PHONE_CALLS)) { say("I need call permission first."); return }
        try {
            ctx.getSystemService(TelecomManager::class.java).endCall()
            say("Call ended.")
        } catch (e: Exception) { say("I couldn't end the call.") }
    }

    // ---- device controls ----
    private fun media(keyCode: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        say("Done.")
    }

    private fun torch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) { say("This phone has no flashlight."); return }
            cm.setTorchMode(id, on)
            say(if (on) "Flashlight on." else "Flashlight off.")
        } catch (e: Exception) {
            say("I couldn't control the flashlight.")
        }
    }

    private fun volume(cmd: String) {
        val am = ctx.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = Regex("(\\d+)").find(cmd)?.groupValues?.get(1)?.toIntOrNull()
        val target = when {
            pct != null -> (pct.coerceIn(0, 100) * max / 100)
            has(cmd, "mute") -> 0
            has(cmd, "up", "louder", "increase") -> minOf(max, cur + 2)
            else -> maxOf(0, cur - 2)
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        say("Volume set to ${target * 100 / max} percent.")
    }

    private fun battery() {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        say("Battery is at $level percent" + if (bm.isCharging) " and charging." else ".")
    }

    private fun timer(cmd: String) {
        val m = Regex("(\\d+)\\s*(second|sec|minute|min|hour|hr)").find(cmd)
        if (m == null) { say("For how long?"); return }
        val n = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val secs = n * when {
            unit.startsWith("hour") || unit.startsWith("hr") -> 3600
            unit.startsWith("min") -> 60
            else -> 1
        }
        launch(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        say("Timer set for $n $unit${if (n == 1) "" else "s"}.")
    }

    private fun alarm(cmd: String) {
        val m = Regex("(\\d{1,2})(?::|\\s)?(\\d{2})?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(cmd.replace("set alarm", ""))
        if (m == null) { say("What time?"); return }
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        val mer = m.groupValues[3].replace(".", "")
        if (mer == "pm" && hour < 12) hour += 12
        if (mer == "am" && hour == 12) hour = 0
        launch(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        say("Alarm set for %02d:%02d.".format(hour, minute))
    }

    private fun openApp(name: String) {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == name }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val intent = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (intent == null) {
            say("I couldn't find an app called $name.")
        } else {
            launch(intent)
            say("Opening $name.")
        }
    }

    // ---- AI brain ----
    private fun askAi(question: String) {
        val key = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("api_key", "") ?: ""
        if (key.isBlank()) {
            say("I didn't recognise that command, and my AI brain has no API key yet.")
            return
        }
        history.put(JSONObject().put("role", "user").put("content", question))
        val snapshot = JSONArray(history.toString())
        Thread {
            val reply = try {
                val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("x-api-key", key)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.setRequestProperty("content-type", "application/json")
                conn.doOutput = true
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                val body = JSONObject()
                    .put("model", "claude-sonnet-5-5")
                    .put("max_tokens", 300)
                    .put("system", "You are JARVIS, a polite, dry-witted voice assistant on a phone. " +
                        "Replies are spoken aloud: one to three short sentences, no markdown, lists or emojis.")
                    .put("messages", snapshot)
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text").trim()
            } catch (e: Exception) {
                null
            }
            main.post {
                if (reply == null) {
                    history.remove(history.length() - 1)
                    say("I couldn't reach my AI brain.")
                } else {
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    while (history.length() > 10) history.remove(0)
                    say(reply)
                }
            }
        }.start()
    }
}
