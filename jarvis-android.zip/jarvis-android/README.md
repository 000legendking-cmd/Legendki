# Jarvis for Android

A hands-free voice assistant that controls your phone. Say "Jarvis" followed by a command.

No coding tools needed on your phone or computer. GitHub builds the APK for you.

## Get the APK

1. Create a free account at github.com and make a new repository (private is fine).
2. Upload everything in this folder to it. Keep the `.github` folder, since it holds the build recipe.
3. Open the repository's **Actions** tab. The **Build APK** run starts by itself. If it doesn't, choose **Build APK**, then **Run workflow**.
4. When the run turns green (about 5 minutes), open it and download **jarvis-debug-apk** under Artifacts. Unzip it to get `app-debug.apk`.
5. Open the APK on your phone and allow "install unknown apps" when asked.

If the build fails, open the failed step, copy the red error text and send it to me. I'll fix it.

## First-time setup in the app

1. **Grant permissions** (microphone, phone, SMS, contacts).
2. **Turn on Jarvis accessibility service.** This is what lets Jarvis tap, scroll and type for you.
   On Android 13 or newer, an app installed from outside the Play Store is blocked at first. Open
   Settings > Apps > Jarvis > the three-dot menu > **Allow restricted settings**, then try again.
3. **Allow display over other apps.** Android needs this before Jarvis can open apps while it runs in the background.
4. **Stop Android putting Jarvis to sleep** so it keeps listening with the screen off.
5. Optional: paste an Anthropic API key to let Jarvis answer any question.
6. Tap **Start hands-free listening**.

## What you can say

- Navigation: "Jarvis, go home", "go back", "recent apps", "open notifications", "quick settings", "take a screenshot", "lock the phone"
- Screen: "scroll down", "scroll up", "swipe left", "tap Search", "tap Send", "type hello world", "tap enter"
- Apps: "open WhatsApp", "open settings", "search for pizza near me", "play lo-fi music", "navigate to the airport"
- Calls and texts: "call Mom", "text Mom saying I'm on my way", "answer the call", "hang up" (it always asks first before calling or texting)
- Media and device: "pause", "next song", "volume 40", "flashlight on", "battery", "set timer 5 minutes", "set alarm 6:30 am"
- Anything else goes to the AI brain if you saved a key.

## Good to know

- Android doesn't let apps switch Wi-Fi, Bluetooth or screen brightness directly, so Jarvis opens the right panel for Wi-Fi and skips the rest.
- Banking apps and some secure screens block taps and typing from accessibility services. That is Android's rule, not a bug.
- The speech recogniser may beep on some phones each time it restarts. Turning down the media volume while idle helps.
- Listening continuously costs battery. Use "Jarvis, stop listening" or the Stop button when you don't need it.
- This build is signed with a debug key, which is fine for your own phone. It is not for the Play Store.
- Only install this on a phone you own. The accessibility permission is powerful, so keep your API key private.
